"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { ChevronLeft, ChevronRight, MapPin, Info, Volume2, Camera, Search, MessageCircle, Send } from "lucide-react"

const birds = [
  {
    id: 1,
    name: "Guardabarranco",
    scientificName: "Eumomota superciliosa",
    status: "Ave Nacional",
    habitat: "Bosques secos y húmedos",
    locations: [
      "Reserva Natural Volcán Masaya",
      "Parque Nacional Saslaya",
      "Reserva Silvestre Privada Domitila",
      "Refugio de Vida Silvestre Río Escalante-Chacocente",
    ],
    habitatImage: "/masaya-volcano-habitat.jpg",
    description:
      "El Guardabarranco es el ave nacional de Nicaragua. Se caracteriza por su cola larga con forma de raqueta y sus colores vibrantes. Es conocido por su comportamiento territorial y su distintivo canto.",
    conservation: "Preocupación menor",
    size: "34-38 cm",
    diet: "Insectos, pequeños reptiles",
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/guardabarranco.png-mMzfmE5c8nSNPOjSSbYTAaoU9Ru1YR.webp", // Using real guardabarranco image
    sound: "Canto melodioso y territorial",
    bestTime: "Temprano en la mañana y al atardecer",
  },
  {
    id: 2,
    name: "Quetzal Resplandeciente",
    scientificName: "Pharomachrus mocinno",
    status: "Especie Emblemática",
    habitat: "Bosques nubosos de montaña",
    locations: [
      "Reserva Natural Cerro Musún",
      "Reserva de Biosfera Bosawás",
      "Selva Negra Ecolodge (Matagalpa)",
      "Reserva Natural Datanlí-El Diablo",
    ],
    habitatImage: "/cloud-forest-habitat.jpg",
    description:
      "El Quetzal es una de las aves más hermosas de Centroamérica. Los machos tienen plumas de cola extremadamente largas y colores iridiscentes. Era considerado sagrado por las culturas precolombinas.",
    conservation: "Casi amenazado",
    size: "36-40 cm (sin cola)",
    diet: "Frutas, insectos, pequeños vertebrados",
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Quetzal.png-LybVjX5aWZOInK3DKvEFsQ0PxTerfE.webp", // Using real quetzal image
    sound: "Llamadas suaves y melodiosas",
    bestTime: "Amanecer en época seca (diciembre-abril)",
  },
  {
    id: 3,
    name: "Lapa Verde",
    scientificName: "Ara ambiguus",
    status: "En Peligro",
    habitat: "Bosques húmedos tropicales",
    locations: [
      "Reserva de Biosfera Bosawás",
      "Reserva Natural Cerro Silva",
      "Refugio de Vida Silvestre Los Guatuzos",
      "Reserva Biológica Indio Maíz",
    ],
    habitatImage: "/tropical-rainforest-habitat.jpg",
    description:
      "La Lapa Verde es el loro más grande de Nicaragua. Su plumaje verde brillante y su gran tamaño la hacen inconfundible. Vive en parejas o grupos familiares y es muy inteligente.",
    conservation: "En peligro",
    size: "85-90 cm",
    diet: "Frutas, semillas, nueces",
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/lapa%20verde.png-DWX3qlgv9w8vWTHR7xMAja9TNZqZxv.webp", // Using real lapa verde image
    sound: "Gritos fuertes y llamadas sociales",
    bestTime: "Mañanas tempranas cuando buscan alimento",
  },
  {
    id: 4,
    name: "Tucán Pico Iris",
    scientificName: "Ramphastos sulfuratus",
    status: "Residente",
    habitat: "Bosques tropicales húmedos",
    locations: [
      "Reserva Natural Cerro Musún",
      "Refugio de Vida Silvestre Los Guatuzos",
      "Reserva Biológica Indio Maíz",
      "Parque Nacional Saslaya",
    ],
    habitatImage: "/humid-tropical-forest-habitat.jpg",
    description:
      "El Tucán Pico Iris es reconocible por su enorme pico colorido. A pesar de su tamaño, el pico es muy liviano. Son aves sociales que viven en grupos y ayudan a dispersar semillas.",
    conservation: "Preocupación menor",
    size: "48-55 cm",
    diet: "Frutas, huevos, insectos",
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/tucan.png-miGtDH35AI9Q3F10mGkrE9nvTdgsPl.webp", // Using real tucan image
    sound: "Llamadas ruidosas y croar profundo",
    bestTime: "Durante el día en las copas de los árboles",
  },
  {
    id: 5,
    name: "Colibrí Garganta Rubí",
    scientificName: "Archilochus colubris",
    status: "Migratorio",
    habitat: "Jardines, bosques abiertos",
    locations: [
      "Jardín Botánico Nacional (Managua)",
      "Reserva Natural Laguna de Apoyo",
      "Selva Negra Ecolodge (Matagalpa)",
      "Reserva Natural Volcán Mombacho",
    ],
    habitatImage: "/garden-habitat.jpg",
    description:
      "Este pequeño colibrí migra desde Norteamérica hasta Nicaragua. Los machos tienen una garganta roja brillante que destella al sol. Son polinizadores importantes de muchas flores.",
    conservation: "Preocupación menor",
    size: "7-9 cm",
    diet: "Néctar, pequeños insectos",
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/colibri.png-OYHwokfCnjdYJEmDsGXID8IQR9AVdL.webp", // Using real colibri image
    sound: "Zumbido de alas y chips agudos",
    bestTime: "Todo el día cerca de flores y comederos",
  },
]

interface Comment {
  id: number
  author: string
  text: string
  date: string
  birdId?: number
}

export default function AvesNicaragua() {
  const [currentBird, setCurrentBird] = useState(0)
  const [selectedBird, setSelectedBird] = useState<number | null>(null)
  const [showHabitat, setShowHabitat] = useState(false)
  const [explorationStarted, setExplorationStarted] = useState(false)
  const [searchTerm, setSearchTerm] = useState("")
  const [filteredBirds, setFilteredBirds] = useState(birds)
  const [comments, setComments] = useState<Comment[]>([])
  const [newComment, setNewComment] = useState({ author: "", text: "" })
  const [showComments, setShowComments] = useState(false)

  useEffect(() => {
    if (explorationStarted) {
      document.body.style.overflow = "auto"
    } else {
      document.body.style.overflow = "hidden"
    }

    return () => {
      document.body.style.overflow = "auto"
    }
  }, [explorationStarted])

  useEffect(() => {
    const filtered = birds.filter(
      (bird) =>
        bird.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        bird.scientificName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        bird.habitat.toLowerCase().includes(searchTerm.toLowerCase()) ||
        bird.locations.some((location) => location.toLowerCase().includes(searchTerm.toLowerCase())),
    )
    setFilteredBirds(filtered)
  }, [searchTerm])

  const nextBird = () => {
    setCurrentBird((prev) => (prev + 1) % filteredBirds.length)
  }

  const prevBird = () => {
    setCurrentBird((prev) => (prev - 1 + filteredBirds.length) % filteredBirds.length)
  }

  const startExploration = () => {
    setExplorationStarted(true)
  }

  const handleCommentSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (newComment.author.trim() && newComment.text.trim()) {
      const comment: Comment = {
        id: Date.now(),
        author: newComment.author,
        text: newComment.text,
        date: new Date().toLocaleDateString("es-ES"),
        birdId: filteredBirds[currentBird]?.id,
      }
      setComments([...comments, comment])
      setNewComment({ author: "", text: "" })
    }
  }

  const bird = filteredBirds[currentBird]

  if (!explorationStarted) {
    return (
      <div className="h-screen overflow-hidden">
        <section className="relative h-screen flex items-center justify-center overflow-hidden">
          <div
            className="absolute inset-0 bg-cover bg-center bg-no-repeat"
            style={{
              backgroundImage: `linear-gradient(rgba(0,0,0,0.4), rgba(0,0,0,0.4)), url('/images/nicaragua-landscape.png')`,
            }}
          />
          <div className="relative z-10 text-center text-white px-4 max-w-4xl mx-auto">
            <h1 className="text-6xl md:text-8xl font-bold mb-6 animate-fade-in-up text-balance">
              Bienvenidos a<span className="block text-accent">Nicabirds</span>
            </h1>
            <p className="text-xl md:text-2xl mb-8 animate-fade-in-up opacity-90 text-pretty">
              Su wiki de aves de confianza - Descubre la rica biodiversidad aviar de Nicaragua
            </p>
            <Button
              size="lg"
              className="animate-fade-in-up bg-primary hover:bg-primary/90 text-primary-foreground px-8 py-4 text-lg"
              onClick={startExploration}
            >
              Explorar Aves
            </Button>
          </div>
        </section>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <section id="gallery" className="py-20 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-4 text-foreground">Pájaros Emblemáticos</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto text-pretty">
              Conoce las especies más representativas de la avifauna nicaragüense y dónde encontrarlas
            </p>

            <div className="mt-8 max-w-md mx-auto">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
                <Input
                  type="text"
                  placeholder="Buscar aves por nombre, hábitat o ubicación..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
          </div>

          {bird && (
            <>
              <div className="grid lg:grid-cols-2 gap-12 items-start mb-16">
                <div className="space-y-4">
                  <div className="flex gap-2 mb-4">
                    <Button
                      variant={!showHabitat ? "default" : "outline"}
                      size="sm"
                      onClick={() => setShowHabitat(false)}
                      className="flex items-center gap-2"
                    >
                      <Volume2 className="w-4 h-4" />
                      Ave
                    </Button>
                    <Button
                      variant={showHabitat ? "default" : "outline"}
                      size="sm"
                      onClick={() => setShowHabitat(true)}
                      className="flex items-center gap-2"
                    >
                      <Camera className="w-4 h-4" />
                      Hábitat
                    </Button>
                  </div>

                  <div className="relative">
                    <div className="aspect-[4/3] rounded-2xl overflow-hidden bg-muted">
                      <img
                        src={showHabitat ? bird.habitatImage : bird.image}
                        alt={showHabitat ? `Hábitat de ${bird.name}` : bird.name}
                        className="w-full h-full object-cover transition-all duration-500 hover:scale-105"
                      />
                    </div>
                    <div className="absolute top-4 right-4">
                      <Badge variant="secondary" className="bg-accent text-accent-foreground">
                        {bird.status}
                      </Badge>
                    </div>
                    {showHabitat && (
                      <div className="absolute bottom-4 left-4 bg-black/70 text-white px-3 py-1 rounded-lg text-sm">
                        Hábitat Natural
                      </div>
                    )}
                  </div>
                </div>

                <div className="space-y-6">
                  <div>
                    <h3 className="text-4xl font-bold text-foreground mb-2">{bird.name}</h3>
                    <p className="text-xl text-muted-foreground italic mb-4">{bird.scientificName}</p>
                    <p className="text-lg text-foreground leading-relaxed text-pretty">{bird.description}</p>
                  </div>

                  <div className="bg-muted/50 rounded-lg p-6 space-y-4">
                    <h4 className="text-xl font-semibold text-foreground flex items-center gap-2">
                      <MapPin className="w-5 h-5 text-primary" />
                      Dónde Encontrarla en Nicaragua
                    </h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {bird.locations.map((location, index) => (
                        <div key={index} className="flex items-center gap-2 text-sm">
                          <div className="w-2 h-2 bg-primary rounded-full flex-shrink-0" />
                          <span className="text-foreground">{location}</span>
                        </div>
                      ))}
                    </div>
                    <div className="mt-4 p-3 bg-primary/10 rounded-lg">
                      <p className="text-sm text-foreground">
                        <strong>Mejor momento para observar:</strong> {bird.bestTime}
                      </p>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-3">
                      <div className="flex items-center gap-2">
                        <MapPin className="w-5 h-5 text-primary" />
                        <span className="font-medium">Hábitat:</span>
                      </div>
                      <p className="text-muted-foreground ml-7">{bird.habitat}</p>
                    </div>

                    <div className="space-y-3">
                      <div className="flex items-center gap-2">
                        <Info className="w-5 h-5 text-primary" />
                        <span className="font-medium">Tamaño:</span>
                      </div>
                      <p className="text-muted-foreground ml-7">{bird.size}</p>
                    </div>

                    <div className="space-y-3">
                      <div className="flex items-center gap-2">
                        <Volume2 className="w-5 h-5 text-primary" />
                        <span className="font-medium">Sonido:</span>
                      </div>
                      <p className="text-muted-foreground ml-7">{bird.sound}</p>
                    </div>

                    <div className="space-y-3">
                      <div className="flex items-center gap-2">
                        <span className="w-5 h-5 text-primary">🍃</span>
                        <span className="font-medium">Dieta:</span>
                      </div>
                      <p className="text-muted-foreground ml-7">{bird.diet}</p>
                    </div>
                  </div>

                  <div className="pt-4">
                    <Badge
                      variant={bird.conservation === "En peligro" ? "destructive" : "secondary"}
                      className="text-sm"
                    >
                      Estado: {bird.conservation}
                    </Badge>
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-center gap-4 mb-12">
                <Button
                  variant="outline"
                  size="lg"
                  onClick={prevBird}
                  className="rounded-full w-12 h-12 p-0 bg-transparent"
                  disabled={filteredBirds.length === 0}
                >
                  <ChevronLeft className="w-6 h-6" />
                </Button>

                <div className="flex gap-2">
                  {filteredBirds.map((_, index) => (
                    <button
                      key={index}
                      onClick={() => setCurrentBird(index)}
                      className={`w-3 h-3 rounded-full transition-all duration-300 ${
                        index === currentBird
                          ? "bg-primary scale-125"
                          : "bg-muted-foreground/30 hover:bg-muted-foreground/50"
                      }`}
                    />
                  ))}
                </div>

                <Button
                  variant="outline"
                  size="lg"
                  onClick={nextBird}
                  className="rounded-full w-12 h-12 p-0 bg-transparent"
                  disabled={filteredBirds.length === 0}
                >
                  <ChevronRight className="w-6 h-6" />
                </Button>
              </div>
            </>
          )}

          {filteredBirds.length === 0 && (
            <div className="text-center py-12">
              <p className="text-xl text-muted-foreground">No se encontraron aves que coincidan con tu búsqueda.</p>
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredBirds.map((birdItem, index) => (
              <Card
                key={birdItem.id}
                className={`cursor-pointer transition-all duration-300 hover:shadow-lg hover:-translate-y-2 ${
                  index === currentBird ? "ring-2 ring-primary" : ""
                }`}
                onClick={() => setCurrentBird(index)}
              >
                <CardContent className="p-0">
                  <div className="aspect-[4/3] rounded-t-lg overflow-hidden">
                    <img
                      src={birdItem.image || "/placeholder.svg"}
                      alt={birdItem.name}
                      className="w-full h-full object-cover transition-transform duration-300 hover:scale-110"
                    />
                  </div>
                  <div className="p-6">
                    <h4 className="text-xl font-bold mb-2 text-foreground">{birdItem.name}</h4>
                    <p className="text-sm text-muted-foreground italic mb-3">{birdItem.scientificName}</p>
                    <Badge variant="outline" className="text-xs">
                      {birdItem.status}
                    </Badge>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="mt-16 max-w-4xl mx-auto">
            <div className="flex items-center justify-between mb-8">
              <h3 className="text-3xl font-bold text-foreground flex items-center gap-2">
                <MessageCircle className="w-8 h-8 text-primary" />
                Comentarios de la Comunidad
              </h3>
              <Button
                variant="outline"
                onClick={() => setShowComments(!showComments)}
                className="flex items-center gap-2"
              >
                <MessageCircle className="w-4 h-4" />
                {showComments ? "Ocultar" : "Mostrar"} Comentarios
              </Button>
            </div>

            {showComments && (
              <div className="space-y-6">
                <Card className="p-6">
                  <h4 className="text-xl font-semibold mb-4">Deja tu comentario</h4>
                  <form onSubmit={handleCommentSubmit} className="space-y-4">
                    <Input
                      placeholder="Tu nombre"
                      value={newComment.author}
                      onChange={(e) => setNewComment({ ...newComment, author: e.target.value })}
                      required
                    />
                    <Textarea
                      placeholder="Comparte tu experiencia observando aves en Nicaragua..."
                      value={newComment.text}
                      onChange={(e) => setNewComment({ ...newComment, text: e.target.value })}
                      rows={4}
                      required
                    />
                    <Button type="submit" className="flex items-center gap-2">
                      <Send className="w-4 h-4" />
                      Enviar Comentario
                    </Button>
                  </form>
                </Card>

                <div className="space-y-4">
                  {comments.length === 0 ? (
                    <Card className="p-6 text-center">
                      <p className="text-muted-foreground">
                        Sé el primero en dejar un comentario sobre las aves de Nicaragua.
                      </p>
                    </Card>
                  ) : (
                    comments.map((comment) => (
                      <Card key={comment.id} className="p-6">
                        <div className="flex items-start justify-between mb-2">
                          <h5 className="font-semibold text-foreground">{comment.author}</h5>
                          <span className="text-sm text-muted-foreground">{comment.date}</span>
                        </div>
                        <p className="text-foreground leading-relaxed">{comment.text}</p>
                        {comment.birdId && (
                          <Badge variant="outline" className="mt-2 text-xs">
                            Sobre: {birds.find((b) => b.id === comment.birdId)?.name}
                          </Badge>
                        )}
                      </Card>
                    ))
                  )}
                </div>
              </div>
            )}
          </div>
        </div>
      </section>

      <footer className="bg-muted py-12 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <h3 className="text-2xl font-bold mb-4 text-foreground">Conservemos Nuestras Aves</h3>
          <p className="text-muted-foreground text-pretty leading-relaxed">
            Nicaragua alberga más de 700 especies de aves. La conservación de sus hábitats es fundamental para preservar
            esta increíble biodiversidad para las futuras generaciones.
          </p>
        </div>
      </footer>
    </div>
  )
}
