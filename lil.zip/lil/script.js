// Bird data with enhanced habitat images
const birds = [
  {
    id: 1,
    name: "Guardabarranco",
    scientificName: "Eumomota superciliosa",
    status: "Ave Nacional",
    habitat: "Bosques secos y húmedos",
    locations: [
      "Reserva Natural Volcán Masaya",
      "Parque Nacional Saslaya",
      "Reserva Silvestre Privada Domitila",
      "Refugio de Vida Silvestre Río Escalante-Chacocente",
    ],
    habitatImage: "/bosque-seco-tropical-con--rboles-dispersos-y-veget.jpg",
    description:
      "El Guardabarranco es el ave nacional de Nicaragua. Se caracteriza por su cola larga con forma de raqueta y sus colores vibrantes. Es conocido por su comportamiento territorial y su distintivo canto.",
    conservation: "Preocupación menor",
    size: "34-38 cm",
    diet: "Insectos, pequeños reptiles",
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/guardabarranco.png-mMzfmE5c8nSNPOjSSbYTAaoU9Ru1YR.webp",
    sound: "Canto melodioso y territorial",
    bestTime: "Temprano en la mañana y al atardecer",
  },
  {
    id: 2,
    name: "Quetzal Resplandeciente",
    scientificName: "Pharomachrus mocinno",
    status: "Especie Emblemática",
    habitat: "Bosques nubosos de montaña",
    locations: [
      "Reserva Natural Cerro Musún",
      "Reserva de Biosfera Bosawás",
      "Selva Negra Ecolodge (Matagalpa)",
      "Reserva Natural Datanlí-El Diablo",
    ],
    habitatImage: "/bosque-nuboso-de-monta-a-con-neblina-y-vegetaci-n-.jpg",
    description:
      "El Quetzal es una de las aves más hermosas de Centroamérica. Los machos tienen plumas de cola extremadamente largas y colores iridiscentes. Era considerado sagrado por las culturas precolombinas.",
    conservation: "Casi amenazado",
    size: "36-40 cm (sin cola)",
    diet: "Frutas, insectos, pequeños vertebrados",
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Quetzal.png-LybVjX5aWZOInK3DKvEFsQ0PxTerfE.webp",
    sound: "Llamadas suaves y melodiosas",
    bestTime: "Amanecer en época seca (diciembre-abril)",
  },
  {
    id: 3,
    name: "Lapa Verde",
    scientificName: "Ara ambiguus",
    status: "En Peligro",
    habitat: "Bosques húmedos tropicales",
    locations: [
      "Reserva de Biosfera Bosawás",
      "Reserva Natural Cerro Silva",
      "Refugio de Vida Silvestre Los Guatuzos",
      "Reserva Biológica Indio Maíz",
    ],
    habitatImage: "/selva-tropical-h-meda-con--rboles-altos-y-vegetaci.jpg",
    description:
      "La Lapa Verde es el loro más grande de Nicaragua. Su plumaje verde brillante y su gran tamaño la hacen inconfundible. Vive en parejas o grupos familiares y es muy inteligente.",
    conservation: "En peligro",
    size: "85-90 cm",
    diet: "Frutas, semillas, nueces",
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/lapa%20verde.png-DWX3qlgv9w8vWTHR7xMAja9TNZqZxv.webp",
    sound: "Gritos fuertes y llamadas sociales",
    bestTime: "Mañanas tempranas cuando buscan alimento",
  },
  {
    id: 4,
    name: "Tucán Pico Iris",
    scientificName: "Ramphastos sulfuratus",
    status: "Residente",
    habitat: "Bosques tropicales húmedos",
    locations: [
      "Reserva Natural Cerro Musún",
      "Refugio de Vida Silvestre Los Guatuzos",
      "Reserva Biológica Indio Maíz",
      "Parque Nacional Saslaya",
    ],
    habitatImage: "/bosque-tropical-h-medo-con-canopy-denso-y--rboles-.jpg",
    description:
      "El Tucán Pico Iris es reconocible por su enorme pico colorido. A pesar de su tamaño, el pico es muy liviano. Son aves sociales que viven en grupos y ayudan a dispersar semillas.",
    conservation: "Preocupación menor",
    size: "48-55 cm",
    diet: "Frutas, huevos, insectos",
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/tucan.png-miGtDH35AI9Q3F10mGkrE9nvTdgsPl.webp",
    sound: "Llamadas ruidosas y croar profundo",
    bestTime: "Durante el día en las copas de los árboles",
  },
  {
    id: 5,
    name: "Colibrí Garganta Rubí",
    scientificName: "Archilochus colubris",
    status: "Migratorio",
    habitat: "Jardines, bosques abiertos",
    locations: [
      "Jardín Botánico Nacional (Managua)",
      "Reserva Natural Laguna de Apoyo",
      "Selva Negra Ecolodge (Matagalpa)",
      "Reserva Natural Volcán Mombacho",
    ],
    habitatImage: "/jard-n-tropical-con-flores-coloridas-y-plantas-nec.jpg",
    description:
      "Este pequeño colibrí migra desde Norteamérica hasta Nicaragua. Los machos tienen una garganta roja brillante que destella al sol. Son polinizadores importantes de muchas flores.",
    conservation: "Preocupación menor",
    size: "7-9 cm",
    diet: "Néctar, pequeños insectos",
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/colibri.png-OYHwokfCnjdYJEmDsGXID8IQR9AVdL.webp",
    sound: "Zumbido de alas y chips agudos",
    bestTime: "Todo el día cerca de flores y comederos",
  },
]

// State variables
let currentBird = 0
let filteredBirds = [...birds]
const comments = []
let showHabitat = false
let showComments = false

// DOM elements
const landingSection = document.getElementById("landing-section")
const mainApp = document.getElementById("main-app")
const exploreBtn = document.getElementById("explore-btn")
const searchInput = document.getElementById("search-input")
const birdDetail = document.getElementById("bird-detail")
const noResults = document.getElementById("no-results")
const birdsGrid = document.getElementById("birds-grid")

// Bird detail elements
const birdImage = document.getElementById("bird-image")
const birdName = document.getElementById("bird-name")
const birdScientific = document.getElementById("bird-scientific")
const birdDescription = document.getElementById("bird-description")
const birdStatus = document.getElementById("bird-status")
const birdLocationsList = document.getElementById("bird-locations-list")
const birdBestTime = document.getElementById("bird-best-time")
const birdHabitat = document.getElementById("bird-habitat")
const birdSize = document.getElementById("bird-size")
const birdSound = document.getElementById("bird-sound")
const birdDiet = document.getElementById("bird-diet")
const birdConservation = document.getElementById("bird-conservation")
const habitatLabel = document.getElementById("habitat-label")

// Navigation elements
const prevBtn = document.getElementById("prev-btn")
const nextBtn = document.getElementById("next-btn")
const dotsContainer = document.getElementById("dots-container")

// Toggle buttons
const birdBtn = document.getElementById("bird-btn")
const habitatBtn = document.getElementById("habitat-btn")

// Comments elements
const toggleCommentsBtn = document.getElementById("toggle-comments")
const commentsContent = document.getElementById("comments-content")
const commentForm = document.getElementById("comment-form")
const commentAuthor = document.getElementById("comment-author")
const commentText = document.getElementById("comment-text")
const commentsList = document.getElementById("comments-list")

// Mapeo de hábitats a imágenes reales
const habitatImages = {
    'Jardín tropical': 'jard-n-tropical-con-flores-coloridas-y-plantas-nec.jpg',
    'Selva tropical húmeda': 'selva-tropical-h-meda-con--rboles-altos-y-vegetaci.jpg',
    'Bosque nuboso': 'bosque-nuboso-de-monta-a-con-neblina-y-vegetaci-n-.jpg',
    'Bosque seco tropical': 'bosque-seco-tropical-con--rboles-dispersos-y-veget.jpg',
    'Bosque tropical húmedo': 'bosque-tropical-h-medo-con-canopy-denso-y--rboles-.jpg',
    // Agrega más si tienes otros hábitats
};

// Guarda el hábitat actual de la especie seleccionada
let currentBirdHabitat = "";

// Esta función la debes llamar cada vez que muestres una nueva ave
function mostrarAve(ave) {
    // ...tu lógica para mostrar datos de la ave...
    document.getElementById('bird-name').textContent = ave.nombre;
    document.getElementById('bird-scientific').textContent = ave.cientifico;
    document.getElementById('bird-description').textContent = ave.descripcion;
    document.getElementById('bird-habitat').textContent = ave.habitat;
    document.getElementById('bird-image').src = ave.imagen;
    // ...otros campos...

    // Actualiza el hábitat actual
    currentBirdHabitat = ave.habitat;
    // Siempre muestra la imagen del ave al cambiar de especie
    showBirdImage();
}

// Muestra la imagen del hábitat
function showHabitatImage() {
    const habitatImage = document.getElementById('habitat-image');
    const birdImage = document.getElementById('bird-image');
    const habitatLabel = document.getElementById('habitat-label');
    // Busca la imagen según el hábitat actual
    const img = habitatImages[currentBirdHabitat] || 'placeholder.jpg';
    habitatImage.src = img;
    habitatImage.classList.remove('hidden');
    birdImage.classList.add('hidden');
    habitatLabel.classList.remove('hidden');
}

// Muestra la imagen del ave
function showBirdImage() {
    document.getElementById('habitat-image').classList.add('hidden');
    document.getElementById('bird-image').classList.remove('hidden');
    document.getElementById('habitat-label').classList.add('hidden');
}

// Navigation functions
function goToHome() {
  // Hide main app and show landing section with smooth transition
  mainApp.classList.add("hidden")
  landingSection.classList.remove("hidden")

  // Reset scroll and overflow
  document.body.style.overflow = "hidden"
  window.scrollTo({ top: 0, behavior: "smooth" })

  // Reset search and filters
  searchInput.value = ""
  filteredBirds = [...birds]
  currentBird = 0
  showHabitat = false
  showComments = false

  // Reset toggle buttons
  birdBtn.classList.add("active")
  habitatBtn.classList.remove("active")

  // Hide comments if they were showing
  if (showComments) {
    toggleCommentsSection()
  }

  console.log("[v0] Returned to home page")
}

// Event listeners
exploreBtn.addEventListener("click", startExploration)
searchInput.addEventListener("input", handleSearch)
prevBtn.addEventListener("click", prevBird)
nextBtn.addEventListener("click", nextBird)
birdBtn.addEventListener("click", () => toggleImageView(false))
habitatBtn.addEventListener("click", () => toggleImageView(true))
toggleCommentsBtn.addEventListener("click", toggleCommentsSection)
commentForm.addEventListener("submit", handleCommentSubmit)

// Initialize app
function startExploration() {
  landingSection.classList.add("hidden")
  mainApp.classList.remove("hidden")
  document.body.style.overflow = "auto"
  updateDisplay()
}

function handleSearch(e) {
  const searchTerm = e.target.value.toLowerCase()
  filteredBirds = birds.filter(
    (bird) =>
      bird.name.toLowerCase().includes(searchTerm) ||
      bird.scientificName.toLowerCase().includes(searchTerm) ||
      bird.habitat.toLowerCase().includes(searchTerm) ||
      bird.locations.some((location) => location.toLowerCase().includes(searchTerm)),
  )

  currentBird = 0
  updateDisplay()
}

function updateDisplay() {
  if (filteredBirds.length === 0) {
    birdDetail.classList.add("hidden")
    noResults.classList.remove("hidden")
    birdsGrid.innerHTML = ""
    dotsContainer.innerHTML = ""
    return
  }

  birdDetail.classList.remove("hidden")
  noResults.classList.add("hidden")

  updateBirdDetail()
  updateNavigation()
  updateBirdsGrid()
}

function updateBirdDetail() {
  const bird = filteredBirds[currentBird]
  if (!bird) return

  // Update image
  birdImage.src = showHabitat ? bird.habitatImage : bird.image
  birdImage.alt = showHabitat ? `Hábitat de ${bird.name}` : bird.name

  // Update text content
  birdName.textContent = bird.name
  birdScientific.textContent = bird.scientificName
  birdDescription.textContent = bird.description
  birdStatus.textContent = bird.status
  birdBestTime.textContent = bird.bestTime
  birdHabitat.textContent = bird.habitat
  birdSize.textContent = bird.size
  birdSound.textContent = bird.sound
  birdDiet.textContent = bird.diet

  // Update conservation status
  birdConservation.textContent = `Estado: ${bird.conservation}`
  birdConservation.className = "conservation-badge " + (bird.conservation === "En peligro" ? "danger" : "safe")

  // Update locations
  birdLocationsList.innerHTML = bird.locations
    .map(
      (location) => `
        <div class="location-item">
            <div class="location-dot"></div>
            <span>${location}</span>
        </div>
    `,
    )
    .join("")

  // Update habitat label visibility
  if (showHabitat) {
    habitatLabel.classList.remove("hidden")
  } else {
    habitatLabel.classList.add("hidden")
  }
}

function updateNavigation() {
  // Update navigation buttons
  prevBtn.disabled = filteredBirds.length === 0
  nextBtn.disabled = filteredBirds.length === 0

  // Update dots
  dotsContainer.innerHTML = filteredBirds
    .map(
      (_, index) => `
        <div class="dot ${index === currentBird ? "active" : ""}" 
             onclick="setCurrentBird(${index})"></div>
    `,
    )
    .join("")
}

function updateBirdsGrid() {
  birdsGrid.innerHTML = filteredBirds
    .map(
      (bird, index) => `
        <div class="bird-card ${index === currentBird ? "active" : ""}" 
             onclick="setCurrentBird(${index})">
            <div class="bird-card-image">
                <img src="${bird.image}" alt="${bird.name}">
            </div>
            <div class="bird-card-content">
                <h4 class="bird-card-title">${bird.name}</h4>
                <p class="bird-card-scientific">${bird.scientificName}</p>
                <span class="bird-card-status">${bird.status}</span>
            </div>
        </div>
    `,
    )
    .join("")
}

function prevBird() {
  if (filteredBirds.length === 0) return
  currentBird = (currentBird - 1 + filteredBirds.length) % filteredBirds.length
  updateDisplay()
}

function nextBird() {
  if (filteredBirds.length === 0) return
  currentBird = (currentBird + 1) % filteredBirds.length
  updateDisplay()
}

function setCurrentBird(index) {
  currentBird = index
  updateDisplay()
}

function toggleImageView(isHabitat) {
  showHabitat = isHabitat

  // Update button states
  if (isHabitat) {
    birdBtn.classList.remove("active")
    habitatBtn.classList.add("active")
  } else {
    birdBtn.classList.add("active")
    habitatBtn.classList.remove("active")
  }

  updateBirdDetail()
}

function toggleCommentsSection() {
  showComments = !showComments

  if (showComments) {
    commentsContent.classList.remove("hidden")
    toggleCommentsBtn.innerHTML = `
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
            </svg>
            Ocultar Comentarios
        `
  } else {
    commentsContent.classList.add("hidden")
    toggleCommentsBtn.innerHTML = `
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
            </svg>
            Mostrar Comentarios
        `
  }
}

function handleCommentSubmit(e) {
  e.preventDefault()

  const author = commentAuthor.value.trim()
  const text = commentText.value.trim()

  if (author && text) {
    const comment = {
      id: Date.now(),
      author: author,
      text: text,
      date: new Date().toLocaleDateString("es-ES"),
      birdId: filteredBirds[currentBird]?.id,
    }

    comments.push(comment)
    commentAuthor.value = ""
    commentText.value = ""
    updateCommentsList()
  }
}

function updateCommentsList() {
  if (comments.length === 0) {
    commentsList.innerHTML = `
            <div class="no-comments-card">
                <p>Sé el primero en dejar un comentario sobre las aves de Nicaragua.</p>
            </div>
        `
    return
  }

  commentsList.innerHTML = comments
    .map((comment) => {
      const bird = birds.find((b) => b.id === comment.birdId)
      return `
            <div class="comment-card">
                <div class="comment-header">
                    <h5 class="comment-author">${comment.author}</h5>
                    <span class="comment-date">${comment.date}</span>
                </div>
                <p class="comment-text">${comment.text}</p>
                ${bird ? `<span class="comment-bird-badge">Sobre: ${bird.name}</span>` : ""}
            </div>
        `
    })
    .join("")
}

// Initialize the app
document.addEventListener("DOMContentLoaded", () => {
  // Set initial state
  document.body.style.overflow = "hidden"
})
